<?php
namespace Core;
class Config
{
    /**
     * Database host
     * @var string
     */
    const DB_HOST = 'localhost';
    /**
     * Database name
     * @var string
     */
    const DB_NAME = 'motarjem1';
    //motarje6_db
    /**
     * Database user
     * @var string
     */
    const DB_USER = 'coderguy';
    //motarje6_user
    /**
     * Database password
     * @var string
     */
    const DB_PASSWORD = 'mgmehdi@159';
    //XA@8k7D#k@{!
    /**
     * Show or hide error messages on screen
     * @var boolean
     */
    const SHOW_ERRORS = true;

    const ENCRYPTION_KEY="c8tUbkNbXDQcuKL3";
    const ENCRYPTION_LENGTH=8;
    const BASE_URL="http://localhost";
    //http://motarjem1.com
    const VERIFY_EMAIL_KEY="c8tUbkNbXDQcuKL3";
}