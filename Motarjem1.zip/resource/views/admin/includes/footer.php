

<!-- Plugins and scripts required by dashboard view-->
 

<!-- Plugins and scripts required by charts.php view-->
<script src="node_modules/chart.js/dist/Chart.min.js"></script>
      <script src="node_modules/@coreui/coreui-plugin-chartjs-custom-tooltips/dist/js/custom-tooltips.min.js"></script>
      <script src="js/charts.js"></script>

<!-- Plugins and scripts required by colors.php view-->
    <script src="js/colors.js"></script>

