<?php
namespace App\Dependencies;
use Exception;
class CurlRequest{
    protected $curl;
    public function __construct($url)
    {
        $this->set_url($url);
    }
    public function set_url($url)
    {
        $this->curl=curl_init($url);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
    }
    public function set_post_fields($fields,$isJson=false)
    {
        if($isJson){
            $fields=json_encode($fields);
            curl_setopt($this->curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($fields)
            ));
            
        }

        curl_setopt($this->curl, CURLOPT_POSTFIELDS, $fields);
    }
    public function set_custom_options($options)
    {
        curl_setopt_array($this->curl,$options);
    }
    public function execute()
    {
        if($this->curl){
            $result = curl_exec($this->curl);
            
            $err = curl_error($this->curl);
            curl_close($this->curl);
            if($err){
                return new Exception("An Error Occured (".$err.")");
            }
            return $result;
        }
    }
    public function execute_and_parse_json($asArray=false)
    {
        $result=$this->execute();
        if($asArray){
            return json_decode($result,true);
        }
        return json_decode($result);
    }

}